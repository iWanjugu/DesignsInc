function goportofolio()
	{

		window.location.href="portfolio.html";
	}

function gohome()
	{

		window.location.href="index.html";
	}





function gocontact()
	{

		window.location.href="contact.html";
	}

